window.searchGeopoliticalViews = window.searchGeopoliticalViews || {
    Unified: 'Unified',
    AR: 'Argentina',
    IN: 'India',
    IL: 'Israel',
    MA: 'Morocco',
    PK: 'Pakistan',
    RU: 'Russia',
    TR: 'Turkey',
    CN: 'China'
};
