window.mapGeopoliticalViews = window.mapGeopoliticalViews || {
    Unified: 'Unified',
    IN: 'India',
    IL: 'Israel',
    MA: 'Morocco',
    PK: 'Pakistan',
    AR: 'Argentina',
    Arabic: 'Arabic',
    RU: 'Russia',
    TR: 'Turkey',
    CN: 'China'
};
