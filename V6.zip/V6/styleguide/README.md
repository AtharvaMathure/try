# UI Library

Library of UI components and guidelines for Maps SDK for Web examples.

## Usage

This styleguide shows how to use the components used in the examples for Maps SDK for Web V6.

To see the styleguide, simple download this repository on your computer and open the index.html file inside the styleguide folder.

To use the assets described in the styleguide, include the relevant stylesheets on your webpage.
